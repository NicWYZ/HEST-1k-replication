#!/bin/bash
# usage: run_merged_B.sh ARM PQARM
ARM=$1; PQARM=$2
W=$(cd $(dirname $0)/..; pwd)
S=/Users/nicolaszhang/hest-1k/HEST-1k-replication-PPI/code/scripts
export PYTHONPATH=$S PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
PQ=$W/q4m/in/b1_predictions__CCRCC_merged__$PQARM.parquet
O=$W/q4m/runs/CCRCC_merged__$ARM
mkdir -p $O; [ -e $O/PROVENANCE.txt ] && { echo exists; exit 0; }
cat > $O/_provenance.json <<J
{"writer":"claude-science","project_id":"proj_3a4e23273fb6","frame_id":"8a3ad045-482e-4604-9184-5d7d08b4ba73","track":"round4-ppi-Q4","plan":"round4_ppi","note":"Q4 CCRCC_merged regime B unit cost and cd/cs 100 rows arm $ARM (local)","host":"$(hostname)","created_at":"$(date -u +%Y-%m-%dT%H:%M:%S+00:00)"}
J
CMD="python $S/round4_ppi_q3_regimes.py --parquet $PQ --vtag CCRCC_merged --arm $ARM --parts B,cost --cd-cs 100 --budgets 2400,4800,9600 --nl-grid 4,6,8,12 --draws 200 --rules none,c_crossfit --tag-suffix __q4mB --out-dir $O"
{ echo "host $(hostname) local; repo tree read-only, scripts at $S (lead states commit aa71028; no git run)"; md5 $S/round4_ppi_q3_regimes.py $S/round4_ppi_q2_masking.py $S/round4_ppi_estimator.py; echo "input md5 $(md5 -q $PQ)"; echo "cmd $CMD"; echo "PYTHONHASHSEED=0 threads=1"; } > $O/PROVENANCE.tmp
S0=$(date +%s); $CMD > $O/stdout.txt 2> $O/stderr.txt; rc=$?; S1=$(date +%s)
{ cat $O/PROVENANCE.tmp; echo "exit $rc; wall_s $((S1-S0))"; } > $O/PROVENANCE.txt; rm $O/PROVENANCE.tmp
