#!/bin/bash
# usage: run_job.sh kind vtag arm   kind = mask20 | regB
export PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/Users/nicolaszhang/HEST-1k-replication-PPI/code/scripts
K=$1; V=$2; A=$3
S=/Users/nicolaszhang/HEST-1k-replication-PPI/code/scripts
W=$(pwd); OUT=$W/out/${K}/${V}__${A}
[ -e "$OUT" ] && { echo EXISTS $OUT; exit 3; }
mkdir -p $OUT
if [ $K = mask20 ]; then
  CMD="python $S/round4_ppi_q2_masking.py --parquet $W/in/$V.parquet --vtag $V --arm $A --theta2-kind mean --nl-grid 20 --draws 200 --rules none,c_crossfit,c_crossfit_design --out-dir $OUT"
else
  if [ $V = ACS_STATES ]; then BUD=1275,2550,5100,10200; else BUD=6625,13250,26500,53000; fi
  CMD="python $S/round4_ppi_q3_regimes.py --parquet $W/in/$V.parquet --vtag $V --arm $A --theta2-kind mean --budgets $BUD --draws 200 --parts B --rules none,c_crossfit,c_crossfit_design --tag-suffix _mG --out-dir $OUT"
fi
{
echo "host: $(hostname) (local darwin run; code from read-only working tree /Users/nicolaszhang/HEST-1k-replication-PPI at commit aa71028 per lead)"
echo "frame: sub-agent of lead 489504c4-ba56-4908-816f-a5c52417f390, own frame id not resolvable from the sandbox; project proj_3a4e23273fb6; unit Q4 ACS interval 3"
md5 $S/round4_ppi_q2_masking.py $S/round4_ppi_q3_regimes.py $S/round4_ppi_estimator.py $S/round4_ppi_q2_theorem_sim.py $W/in/$V.parquet
echo "input md5 on Longleaf (verified equal after download): ACS_STATES e18604e1e915ff51f2668719e397ab7a, ACS_CA_PUMA c581e8d0a04c989cfebfe6ee888feb90"
echo "PYTHONHASHSEED=0 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$S"
echo "command: $CMD"
python -c "import sys,numpy,pandas,scipy;print(sys.version.split()[0],'numpy',numpy.__version__,'pandas',pandas.__version__,'scipy',scipy.__version__)"
} > $OUT/PROVENANCE.txt 2>&1
cat > $OUT/_provenance.json <<PE
{"writer":"claude-science","project_id":"proj_3a4e23273fb6","frame_id":"unresolved (sub-agent of 489504c4-ba56-4908-816f-a5c52417f390)","track":"ppi-Q4-ACS","note":"Q4 ACS phase 1 $K $V $A, local run","host":"$(hostname)","created_at":"$(date -u +%Y-%m-%dT%H:%M:%S+00:00)"}
PE
T0=$(date +%s)
/usr/bin/time -l $CMD > $OUT/stdout.txt 2> $OUT/stderr.txt; RC=$?
echo "exit=$RC wall_s=$(( $(date +%s)-T0 ))" >> $OUT/PROVENANCE.txt
grep "maximum resident" $OUT/stderr.txt >> $OUT/PROVENANCE.txt
exit $RC
